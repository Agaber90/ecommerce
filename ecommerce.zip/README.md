Develop a small e-commerce web API using synchronous communication between microservices using .NET 6.
