﻿namespace Ecommerce.API.Search.Models;

public class SearchTerm
{
    public int CustomerId { get; set; }
}

